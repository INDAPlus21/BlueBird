public class main extends Class1
{
    static int call = 5; // get input
}