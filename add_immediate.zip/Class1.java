public class Class1 extends Class2
{
    static int addi = 15; // add 15 (immediate)
}