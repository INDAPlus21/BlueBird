public class Class2
{
    static int call = 1; // print output
}