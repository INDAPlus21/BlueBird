
/**
 * Write a description of class save_sum3 here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class save_sum3 extends save_inner2
{
    static int save = 3; // save to register 3
    
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class save_sum3
     */
    public save_sum3()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
